<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname="DATAXUONG";
$conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);


