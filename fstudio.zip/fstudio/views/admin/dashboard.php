<?php include "views/layouts/header-admin.php"?>
<h3>Dash
    board</h3>
<?php include "views/layouts/footer-admin.php"?>